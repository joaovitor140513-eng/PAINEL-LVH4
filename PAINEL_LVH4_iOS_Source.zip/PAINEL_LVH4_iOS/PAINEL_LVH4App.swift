import SwiftUI

@main
struct PAINEL_LVH4App: App {
    var body: some Scene {
        WindowGroup { DashboardView() }
    }
}
