import SwiftUI

private let lvRed = Color(red: 1.0, green: 0.08, blue: 0.16)
private let lvBG = Color(red: 0.035, green: 0.035, blue: 0.045)

struct DashboardView: View {
    @AppStorage("lvh4_sensi") private var sensitivity = 92.0
    @AppStorage("lvh4_red_dot") private var redDot = 88.0
    @AppStorage("lvh4_fire_button") private var fireButton = 48.0
    @AppStorage("lvh4_profile") private var profile = "Equilibrado"
    @State private var selectedTab = 0

    var body: some View {
        ZStack {
            lvBG.ignoresSafeArea()
            VStack(spacing: 0) {
                header
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if selectedTab == 0 { dashboard }
                        else if selectedTab == 1 { profiles }
                        else { info }
                    }
                    .padding(16)
                }
                tabBar
            }
        }
        .preferredColorScheme(.dark)
        .tint(lvRed)
    }

    private var header: some View {
        HStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 12).fill(lvRed).frame(width: 42, height: 42)
                Image(systemName: "crown.fill").font(.system(size: 21, weight: .black)).foregroundStyle(.white)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text("PAINEL LVH4").font(.system(size: 20, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text("FREE FIRE • iOS").font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(2).foregroundStyle(lvRed)
            }
            Spacer()
            Image(systemName: "slider.horizontal.3").font(.system(size: 18, weight: .bold)).foregroundStyle(.white.opacity(0.8))
        }.padding(.horizontal, 18).padding(.vertical, 14)
        .background(Color.black.opacity(0.6))
        .overlay(alignment: .bottom) { Rectangle().fill(lvRed.opacity(0.6)).frame(height: 1) }
    }

    private var dashboard: some View {
        VStack(spacing: 16) {
            ZStack(alignment: .bottomLeading) {
                RoundedRectangle(cornerRadius: 20).fill(LinearGradient(colors: [Color(red: 0.25, green: 0.015, blue: 0.04), .black], startPoint: .topLeading, endPoint: .bottomTrailing))
                Circle().fill(lvRed.opacity(0.15)).frame(width: 180).blur(radius: 12).offset(x: 180, y: -20)
                VStack(alignment: .leading, spacing: 8) {
                    Text("SEU JOGO. SEU ESTILO.").font(.system(size: 11, weight: .heavy)).tracking(2).foregroundStyle(lvRed)
                    Text("Ajuste suas\nconfigurações").font(.system(size: 27, weight: .black, design: .rounded)).foregroundStyle(.white)
                    Text("Salve perfis e consulte seus valores antes de jogar.").font(.system(size: 13)).foregroundStyle(.white.opacity(0.7))
                }.padding(20)
            }.frame(height: 168).clipShape(RoundedRectangle(cornerRadius: 20))

            HStack(spacing: 10) {
                quickCard(icon: "scope", title: "MIRA", detail: "Ajustes manuais")
                quickCard(icon: "hand.tap.fill", title: "BOTÃO DE TIRO", detail: "Tamanho sugerido")
            }

            VStack(alignment: .leading, spacing: 18) {
                sectionTitle("SENSIBILIDADE", icon: "slider.horizontal.3")
                valueSlider("Geral", value: $sensitivity)
                valueSlider("Red Dot", value: $redDot)
                valueSlider("Botão de tiro", value: $fireButton)
                Text("Os valores são sugestões para você testar e ajustar manualmente dentro do Free Fire.")
                    .font(.system(size: 11)).foregroundStyle(.white.opacity(0.55))
            }.padding(16).background(Color.white.opacity(0.045)).clipShape(RoundedRectangle(cornerRadius: 18)).overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.08), lineWidth: 1))

            VStack(alignment: .leading, spacing: 12) {
                sectionTitle("PERFIL ATUAL", icon: "person.crop.square")
                Picker("Perfil", selection: $profile) {
                    Text("Equilibrado").tag("Equilibrado")
                    Text("Movimentação rápida").tag("Movimentação rápida")
                    Text("Precisão").tag("Precisão")
                    Text("Personalizado").tag("Personalizado")
                }.pickerStyle(.menu).tint(lvRed).padding(10).frame(maxWidth: .infinity, alignment: .leading).background(.black.opacity(0.35)).clipShape(RoundedRectangle(cornerRadius: 12))
            }.padding(16).background(Color.white.opacity(0.045)).clipShape(RoundedRectangle(cornerRadius: 18))

            Label("Este app não modifica o Free Fire nem ativa aimbot/headshot automático.", systemImage: "info.circle.fill")
                .font(.system(size: 11, weight: .medium)).foregroundStyle(.white.opacity(0.65)).frame(maxWidth: .infinity, alignment: .leading).padding(12)
        }
    }

    private var profiles: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionTitle("SEUS PERFIS", icon: "square.stack.3d.up.fill")
            ForEach(["Equilibrado", "Movimentação rápida", "Precisão", "Personalizado"], id: \.self) { name in
                Button { profile = name } label: {
                    HStack(spacing: 12) {
                        Image(systemName: profile == name ? "checkmark.circle.fill" : "circle").foregroundStyle(lvRed).font(.title3)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(name).font(.system(size: 15, weight: .bold)).foregroundStyle(.white)
                            Text(name == "Precisão" ? "Foco em ajustes controlados" : name == "Movimentação rápida" ? "Para quem joga em ritmo acelerado" : "Configuração para testar no jogo").font(.system(size: 11)).foregroundStyle(.white.opacity(0.55))
                        }
                        Spacer()
                    }.padding(15).background(Color.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 14)).overlay(RoundedRectangle(cornerRadius: 14).stroke(profile == name ? lvRed.opacity(0.7) : .white.opacity(0.08), lineWidth: 1))
                }.buttonStyle(.plain)
            }
            Text("A seleção do perfil é salva neste iPhone. Aplique os valores manualmente nas configurações do jogo.").font(.system(size: 12)).foregroundStyle(.white.opacity(0.55)).padding(.top, 4)
        }
    }

    private var info: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionTitle("SOBRE O PAINEL", icon: "info.circle.fill")
            Text("PAINEL LVH4").font(.system(size: 28, weight: .black, design: .rounded)).foregroundStyle(lvRed)
            Text("Um painel independente para organizar e guardar suas configurações de sensibilidade.").foregroundStyle(.white.opacity(0.8))
            Divider().overlay(.white.opacity(0.1))
            infoRow("Compatibilidade", "iPhone com versão iOS suportada")
            infoRow("Armazenamento", "Valores guardados localmente")
            infoRow("Integração com o jogo", "Manual; não altera o Free Fire")
            infoRow("Trapaças automáticas", "Não incluídas")
        }.padding(18).background(Color.white.opacity(0.045)).clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private var tabBar: some View {
        HStack {
            tabButton("house.fill", title: "Início", index: 0)
            tabButton("square.stack.3d.up.fill", title: "Perfis", index: 1)
            tabButton("info.circle.fill", title: "Info", index: 2)
        }.padding(.top, 12).padding(.bottom, 8).background(.black.opacity(0.85)).overlay(alignment: .top) { Rectangle().fill(.white.opacity(0.08)).frame(height: 1) }
    }

    private func tabButton(_ icon: String, title: String, index: Int) -> some View {
        Button { selectedTab = index } label: {
            VStack(spacing: 5) { Image(systemName: icon).font(.system(size: 18, weight: .bold)); Text(title).font(.system(size: 10, weight: .bold)) }
                .foregroundStyle(selectedTab == index ? lvRed : .white.opacity(0.5)).frame(maxWidth: .infinity)
        }.buttonStyle(.plain)
    }

    private func quickCard(icon: String, title: String, detail: String) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            Image(systemName: icon).font(.system(size: 23, weight: .bold)).foregroundStyle(lvRed)
            Text(title).font(.system(size: 12, weight: .black)).foregroundStyle(.white)
            Text(detail).font(.system(size: 10)).foregroundStyle(.white.opacity(0.55))
        }.frame(maxWidth: .infinity, minHeight: 88, alignment: .leading).padding(14).background(Color.white.opacity(0.045)).clipShape(RoundedRectangle(cornerRadius: 16)).overlay(RoundedRectangle(cornerRadius: 16).stroke(lvRed.opacity(0.25), lineWidth: 1))
    }

    private func sectionTitle(_ title: String, icon: String) -> some View {
        HStack(spacing: 8) { Image(systemName: icon).foregroundStyle(lvRed); Text(title).font(.system(size: 13, weight: .black)).tracking(1.2).foregroundStyle(.white); Spacer() }
    }

    private func valueSlider(_ title: String, value: Binding<Double>) -> some View {
        VStack(spacing: 7) {
            HStack { Text(title).font(.system(size: 13, weight: .semibold)).foregroundStyle(.white.opacity(0.85)); Spacer(); Text("\(Int(value.wrappedValue))").font(.system(size: 13, weight: .black, design: .monospaced)).foregroundStyle(lvRed) }
            Slider(value: value, in: 0...100, step: 1).tint(lvRed)
        }
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack(alignment: .top) { Text(title).font(.system(size: 12, weight: .semibold)).foregroundStyle(.white.opacity(0.7)); Spacer(minLength: 12); Text(value).font(.system(size: 12)).multilineTextAlignment(.trailing).foregroundStyle(.white) }
    }
}
