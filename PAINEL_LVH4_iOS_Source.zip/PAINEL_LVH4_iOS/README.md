# PAINEL LVH4 — projeto nativo iOS (SwiftUI)

Este é o código-fonte de uma aplicação nativa para iPhone, com interface escura/preta e vermelha, sliders de configuração, seleção de perfis e armazenamento local com `@AppStorage`.

## Importante
- Não é um site; o app é escrito em SwiftUI para iOS.
- O ZIP contém o código-fonte, não um IPA assinado pronto para instalar.
- Para compilar, assinar e instalar no iPhone, é necessário um Mac com Xcode e uma conta Apple. A assinatura e distribuição dependem das regras atuais da Apple.
- O app não injeta código no Free Fire, não desenha uma sobreposição sobre o jogo e não oferece aimbot/headshot automático. As configurações são sugestões salvas para consulta e aplicação manual.

## Abrir no Xcode
1. Crie um novo projeto iOS > App chamado `PAINEL_LVH4`, usando SwiftUI e Swift.
2. Substitua o arquivo principal gerado por `PAINEL_LVH4App.swift` e adicione `DashboardView.swift` ao target.
3. Defina o deployment target para iOS 16 ou superior.
4. Escolha seu Team em Signing & Capabilities e execute no simulador ou iPhone conectado.

Bundle identifier sugerido: `com.example.PainelLVH4` (troque por um identificador seu antes de distribuir).
